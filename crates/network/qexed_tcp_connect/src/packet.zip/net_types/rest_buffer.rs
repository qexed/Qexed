use serde::de::{Deserialize, Deserializer, Error, SeqAccess, Visitor};
use serde::ser::{Serialize, Serializer, SerializeSeq};
use std::fmt;
#[derive(Debug, Default, PartialEq,Clone)]
pub struct RestBuffer(pub Vec<u8>);
impl RestBuffer{
    pub fn new() -> Self {
        RestBuffer(Vec::new())
    }
}